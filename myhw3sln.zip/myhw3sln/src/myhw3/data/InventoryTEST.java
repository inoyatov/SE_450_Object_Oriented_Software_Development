package myhw3.data;

import static org.junit.Assert.*;
import org.junit.Test;

public class InventoryTEST {
	/*<private todo="complete the tests"/>*/	
	@Test
	public void testNothing() {
		assertEquals (1, 1);
	}
}
