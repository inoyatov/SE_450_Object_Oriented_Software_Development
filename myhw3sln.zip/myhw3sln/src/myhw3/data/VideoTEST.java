package myhw3.data;

import static org.junit.Assert.*;
import org.junit.Test;

public class VideoTEST {
	/*<private todo="complete the tests"/>*/	
	@Test
	public void testNothing() {
		assertEquals (1, 1);
	}
}
