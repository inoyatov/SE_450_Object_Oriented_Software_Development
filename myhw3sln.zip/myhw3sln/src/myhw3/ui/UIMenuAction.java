package myhw3.ui;

public interface UIMenuAction {
	public void run();
}
