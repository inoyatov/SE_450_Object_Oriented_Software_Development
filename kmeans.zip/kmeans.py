
# coding: utf-8

# In[1]:

## Import warnings. Supress warnings (for  matplotlib)
import warnings
warnings.filterwarnings("ignore")


# In[2]:

## Import Scikit Learn KMeans
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans

## Import visualization modules
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab


# In[3]:

## Create sample data
X, y = make_blobs(n_samples=150,
        n_features=2,
        centers=3,
        cluster_std=0.5,
        shuffle=True,
        random_state=0)


# In[4]:

## Plot features
plt.scatter(X[:,0],
            X[:,1],
            c='white',
            marker='o',
            s=50)
plt.grid()
plt.show()


# In[5]:

## Create the estimator
km = KMeans(n_clusters=3)


# In[6]:

## Fit the model
transformed = km.fit_transform(X)


# In[7]:

## Predict X 
predictions = km.predict(X) 


# In[8]:

## Examine predictions
predictions


# In[9]:

## Plot clusters
plt.scatter(X[predictions==0,0],
            X[predictions ==0,1],
         s=50,
        c='lightgreen',
        marker='s',
        label='cluster 1')
plt.scatter(X[predictions ==1,0],
            X[predictions ==1,1],
            s=50,
            c='orange',
            marker='o',
            label='cluster 2')
plt.scatter(X[predictions ==2,0],
            X[predictions ==2,1],
            s=50,
            c='lightblue',
            marker='v',
            label='cluster 3')
plt.scatter(km.cluster_centers_[:,0],
            km.cluster_centers_[:,1],
            s=250,
            marker='*',
            c='red',
            label='centroids')
plt.legend()
plt.grid()
plt.show()

