package composite.three;
public interface Expr {
	int eval();
}
