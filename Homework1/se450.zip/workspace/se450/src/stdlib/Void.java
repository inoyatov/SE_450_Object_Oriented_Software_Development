package stdlib;
/** A class with no instances; variables of this type must be null. */
public class Void {
	private Void() {}
}

