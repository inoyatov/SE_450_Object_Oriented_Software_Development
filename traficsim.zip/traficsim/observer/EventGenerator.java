package traficsim.observer;

public interface EventGenerator {
	public void generate();
}
