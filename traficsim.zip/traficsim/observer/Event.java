package traficsim.observer;

public interface Event {

}
