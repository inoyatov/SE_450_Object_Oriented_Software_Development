package traficsim.observer;


public interface EventSubscriber {

abstract void messageReceived (Event e);

}
