# SE450_Traffic_Simulator
Final Project for SE 450 which creates random number of cars on a set grid of roads. 
