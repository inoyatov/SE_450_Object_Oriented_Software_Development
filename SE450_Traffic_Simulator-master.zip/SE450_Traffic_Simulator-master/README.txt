HOW TO RUN TRAFFIC SIMULATOR: 

It compiles like the previous homeworks and it should run similar to the example project with the GUI. 

TRAFFIC LIGHTS: 

Red light shown means the horizontal roads have the green light. Green is for vertical roads. 

KNOWN BUGS: 

Too many cars will eventually slow down the program and the cars may flicker in the animation. 

