package sim.ui;

/**
 * Interface that establishes the UI test
 * 
 * @author rodri_000
 *
 */
public interface UIFormTest {
	public boolean run(String input);
}
