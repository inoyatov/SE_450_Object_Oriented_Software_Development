package sim.model;

public interface SegmentStrategy {
	public Source makeSegment();
}
