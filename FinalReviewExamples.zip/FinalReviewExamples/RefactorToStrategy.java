public interface IPasswordHasher { 
	public String hash(); 
} 
class PasswordHasher implements IPasswordHasher { 
	private String _password; 
	private IHashingAlgorithm _hashingAlgorithm;
	PasswordHasher(String password, IHashingAlgorithm hashingAlgorithm) { 
		_password = password; 
		_hashingAlgorithm = hashingAlgorithm; 
	}
 	public String hash() { 
		String salt = // create salt 
		return _hashingAlgorithm.getHash(password, salt;) 
	 }
} 

public interface IHashingAlgorithm{
	String getHash(String password, String salt);
}

public class MD5HashingAlgorithm implements IHashingAlgorithm{
	public String getHash(String password, String salt){
		// MD5 Hashing Algorithm
	}
}

public class SHA256HashingAlgorithm implements IHashingAlgorithm {
	public String getHash(String password, String salt){
		// SHA-256 Hashing Algorithm 
	}
}

public class PasswordHasherFactory {
	public static IPasswordHasher createMD5(String password){
		return new PasswordHasher(password, new MD5HashingAlgorithm());
	}
	public static IPasswordHasher createSHA256(String password){
		return new PasswordHasher(password, new SHA256HashingAlgorithm());
	}
}