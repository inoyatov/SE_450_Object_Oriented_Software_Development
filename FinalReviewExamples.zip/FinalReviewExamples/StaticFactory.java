public interface IPasswordHasher { 
	public String hash(); 
} 
class SHA256 implements IPasswordHasher { 
	private String _password; 
	SHA256(String password) { _password = password; }
 	public String hash() { 
		String salt = // create salt 
		return getHashedPassword(_password, salt);
	 } 
	public String getHashedPassword(String password, String salt){ // SHA-256 Hashing Algorithm } 
} 
class MD5 implements IPasswordHasher { 
	private String _password; 
	MD5(String password) { _password = password; } 
	public String hash() { 
		String salt = // create salt 
		return getHashedPassword(_password, salt); 
	} 
	public String getHashedPassword(String password, String salt){ // SHA-256 Hashing Algorithm } 
}

public class PasswordHasherFactory {
	public static IPasswordHasher createMD5(String password){
		return new MD5(password);
	}
	public static IPasswordHasher createSHA256(String password){
		return new SHA256(password);
	}
}