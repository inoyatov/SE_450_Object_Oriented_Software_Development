public interface IPasswordHasher { 
	public String hash(); 
} 
abstract class PasswordHasher implements IPasswordHasher { 
	private String _password; 
	PasswordHasher(String password) { _password = password; }
 	public String hash() { 
		String salt = // create salt 
		return getHashedPassword(_password, salt);
	 } 
	public abstract String getHashedPassword(String password, String salt);
} 


class SHA256 extends PasswordHasher { 
	public String getHashedPassword(String password, String salt){ // SHA-256 Hashing Algorithm } 
}

class MD5 extends PasswordHasher {
	public String getHashedPassword(String password, String salt){ // MD5 Hashing Algorithm } 
}

public class PasswordHasherFactory {
	public static IPasswordHasher createMD5(String password){
		return new MD5(password);
	}
	public static IPasswordHasher createSHA256(String password){
		return new SHA256(password);
	}
}